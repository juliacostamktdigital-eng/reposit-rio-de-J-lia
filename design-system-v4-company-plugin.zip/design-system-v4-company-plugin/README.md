# V4 Company Plugin
**Sistema de Design e Identidade de Marca para IA**
Versão 1.2.0 · Abril 2026

Desenvolvido por **Ruan Silva — Colli & Co**

---

## O que é isso

Plugin de IA que ensina o Claude a criar apresentações, documentos e materiais de comunicação com a identidade visual da V4 Company — seguindo rigorosamente o brandbook oficial (cores, tipografia, tom de voz, logo, grafismos).

Com o plugin instalado, basta pedir ao Claude o que você quer criar. Ele já sabe o brandbook.

---

## O que tem aqui

```
v4-company-plugin/
├── cowork/           → versão para Claude Cowork (desktop app)
├── claude-code/      → versão para Claude Code (terminal)
└── README.md         → este arquivo
```

Cada pasta contém:
- `v4-company.plugin` — arquivo de instalação
- `assets/logos/` — 4 versões do logo V4 (ícone e horizontal, branco e vermelho)
- `assets/fonts/Morganite/` — fonte oficial de títulos (18 pesos)
- `assets/fonts/IBMPlexSans/` — fonte institucional de corpo (7 pesos)
- `INSTALACAO.md` — instruções específicas para cada plataforma

---

## Skills incluídos

| Skill | Função |
|-------|--------|
| **v4-brand-v2** | Brandbook completo — fonte única de verdade da marca |
| **v4-slides** | Criação de apresentações `.pptx` com identidade V4 |
| **v4-docs** | Criação de documentos `.docx` com identidade V4 |

Os skills `v4-slides` e `v4-docs` referenciam `v4-brand-v2` como base — qualquer atualização de marca se propaga automaticamente.

---

## Instalação rápida

### Cowork
1. Abra a pasta `cowork/`
2. Instale as fontes (selecionar `.ttf` → botão direito → Instalar)
3. Arraste `v4-company.plugin` para o app Cowork

### Claude Code
1. Abra a pasta `claude-code/`
2. Instale as fontes (selecionar `.ttf` → botão direito → Instalar)
3. No terminal: `claude plugin install v4-company.plugin --scope user`

Ver `INSTALACAO.md` dentro de cada pasta para mais detalhes.

---

## Exemplos de uso

> "Cria uma apresentação de proposta comercial com identidade V4"

> "Faz um relatório de performance mensal no formato V4"

> "Revisa esse material e diz se está dentro do brandbook V4"

> "Adiciona um slide de agenda ao deck que te enviei"

---

## Especificações técnicas

| Item | Detalhe |
|------|---------|
| Vermelho V4 | `#E50914` |
| Fundo padrão | `#1A1814` |
| Amarelo | `#FFDD00` |
| Fonte títulos | Morganite Black / Bold |
| Fonte corpo | IBM Plex Sans Regular / Light |
| Logo slides | Canto inferior direito, 0.45"×0.45" |
| Formato slides | 16:9 (10" × 5.625") |

---

## Histórico de versões

| Versão | O que mudou |
|--------|-------------|
| 1.2.0 | Logo no canto inferior direito, sem watermark de número, diretriz `//` no título |
| 1.1.0 | Assets atualizados (logos + fontes Morganite + IBM Plex Sans) |
| 1.0.0 | Versão inicial — 3 skills, brandbook auditado |

---

*Desenvolvido por Ruan Silva — Colli & Co · Abril 2026*
*Baseado no Brandbook Oficial V4 Company (124 páginas)*
