# V4 Company Plugin — Claude Code

Duas opções de instalação. Escolha uma.

---

## Opção A — Plugin (recomendado, persiste globalmente)

Instala o plugin para o seu usuário, disponível em todos os projetos:

```bash
claude plugin install v4-company.plugin --scope user
```

Para instalar apenas no projeto atual:

```bash
claude plugin install v4-company.plugin --scope project
```

---

## Opção B — Skills manuais (por projeto)

Copie a pasta `.claude/` para a raiz do seu projeto:

```
seu-projeto/
└── .claude/
    └── skills/
        ├── v4-brand-v2/
        │   └── SKILL.md
        ├── v4-slides/
        │   └── SKILL.md
        └── v4-docs/
            └── SKILL.md
```

Os skills ficam ativos automaticamente no Claude Code dentro desse projeto.

---

## Skills disponíveis

| Skill | Quando usar |
|-------|-------------|
| `v4-brand-v2` | Identidade de marca — cores, tipografia, tom de voz |
| `v4-slides` | Criação de .pptx com identidade V4 |
| `v4-docs` | Criação de .docx com identidade V4 |

## Versão
v1.2.0 — Abril 2026

## Assets incluídos

Instale as fontes no Windows antes de usar:
- `assets/fonts/Morganite/` → selecionar todos os `.ttf` → botão direito → **Instalar**
- `assets/fonts/IBMPlexSans/` → selecionar todos os `.ttf` → botão direito → **Instalar**

Os logos estão em `assets/logos/` prontos para uso.
