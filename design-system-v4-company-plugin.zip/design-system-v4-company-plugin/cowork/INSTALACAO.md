# V4 Company Plugin — Cowork

## Como instalar

1. Abra o Claude Cowork no desktop
2. Arraste o arquivo `v4-company.plugin` para a janela do app
   — ou clique no ícone de plugins e selecione "Instalar plugin"
3. Confirme a instalação

O plugin fica disponível em **todas as sessões** automaticamente.

## Skills disponíveis após instalar

| Skill | Quando usar |
|-------|-------------|
| `v4-brand-v2` | Ativado automaticamente em qualquer tarefa com a marca V4 |
| `v4-slides` | Ativado ao pedir slides, apresentações ou decks V4 |
| `v4-docs` | Ativado ao pedir relatórios, propostas ou docs Word V4 |

## Exemplos de uso

> "Cria uma apresentação de proposta comercial com identidade V4"
> "Faz um relatório de performance no formato V4"
> "Revisa esse material e diz se está dentro do brandbook V4"

## Versão
v1.2.0 — Abril 2026

## Assets incluídos

Instale as fontes no Windows antes de usar:
- `assets/fonts/Morganite/` → selecionar todos os `.ttf` → botão direito → **Instalar**
- `assets/fonts/IBMPlexSans/` → selecionar todos os `.ttf` → botão direito → **Instalar**

Os logos estão em `assets/logos/` prontos para uso.
